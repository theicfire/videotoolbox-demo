//
//  ViewController.h
//  MetalH264Player
//
//  Created by  Ivan Ushakov on 25.12.2019.
//  Copyright © 2019 Lunar Key. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController

@end
